---
layout: page
title: About
---

**Not Pure Poole** is a simple, beautiful, and powerful Jekyll theme for blogs. It is built on [Poole](https://github.com/poole/poole) and [Pure](https://purecss.io/).

For more information about Not Pure Poole, please browse the [README](https://github.com/vszhub/not-pure-poole) file.
