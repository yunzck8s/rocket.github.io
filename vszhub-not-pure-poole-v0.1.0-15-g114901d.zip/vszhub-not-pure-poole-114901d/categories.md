---
layout: archive-taxonomies
permalink: /categories/
title: Categories
type: categories
---
